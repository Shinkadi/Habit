package com.ledger.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class LockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val limitHit = intent.getStringExtra("reason") == "limit"
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#15191c"))
            setPadding(64, 64, 64, 64)
        }
        val msg = if (limitHit) {
            val m = Store.limitMin(this)
            "Screen time limit reached\n\nYou've used your ${m / 60}h ${m % 60}m for today.\nIt resets at midnight. Calls and The Ledger still work."
        } else {
            "Locked\n\nFinish your tasks in The Ledger to earn app time.\nEarned today: ${Store.earnedMs(this) / 60000} min"
        }
        col.addView(TextView(this).apply {
            text = msg
            setTextColor(Color.parseColor("#ede8de")); textSize = 20f; gravity = Gravity.CENTER
        })
        col.addView(Button(this).apply {
            text = "Open The Ledger"
            setOnClickListener { startActivity(Intent(this@LockActivity, MainActivity::class.java)); finish() }
        })
        col.addView(Button(this).apply { text = "Go home"; setOnClickListener { goHome() } })
        setContentView(col)
    }
    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = goHome()
}
