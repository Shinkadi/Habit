package com.ledger.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Store {
    const val DEFAULT_BLOCKED = "com.instagram.android,jp.konami.pesam"
    const val DEFAULT_LIMIT_MIN = 150 // 2.5 hours of total screen time per day
    private val fmt get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun p(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)
    fun today(): String = fmt.format(Date())
    fun tomorrow(): String = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }.let { fmt.format(it.time) }

    fun blocked(c: Context): Set<String> =
        p(c).getString("blocked", DEFAULT_BLOCKED)!!.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun earnedMs(c: Context): Long {
        val s = p(c)
        return if (s.getString("earnedDate", "") == today()) s.getInt("earnedMin", 0) * 60000L else 0L
    }
    fun usedMs(c: Context): Long {
        val s = p(c)
        return if (s.getString("usedDate", "") == today()) s.getLong("usedMs", 0L) else 0L
    }
    fun addUsed(c: Context, ms: Long) {
        p(c).edit().putString("usedDate", today()).putLong("usedMs", usedMs(c) + ms).apply()
    }

    // ---- total screen time (all apps except exempt ones) ----
    fun screenMs(c: Context): Long {
        val s = p(c)
        return if (s.getString("screenDate", "") == today()) s.getLong("screenMs", 0L) else 0L
    }
    fun addScreen(c: Context, ms: Long) {
        p(c).edit().putString("screenDate", today()).putLong("screenMs", screenMs(c) + ms).apply()
    }

    // Lowering the limit applies immediately; raising it only takes effect tomorrow.
    fun limitMin(c: Context): Int {
        val s = p(c)
        val pend = s.getInt("limPend", 0)
        if (pend > 0 && today() >= (s.getString("limFrom", "") ?: "")) {
            s.edit().putInt("limMin", pend).remove("limPend").remove("limFrom").apply()
        }
        return s.getInt("limMin", DEFAULT_LIMIT_MIN)
    }
    fun pendingLimit(c: Context): Int { limitMin(c); return p(c).getInt("limPend", 0) }
    fun setLimit(c: Context, minutes: Int): String {
        val m = minutes.coerceIn(30, 720)
        val e = p(c).edit()
        return if (m <= limitMin(c)) {
            e.putInt("limMin", m).remove("limPend").remove("limFrom").apply(); "now"
        } else {
            e.putInt("limPend", m).putString("limFrom", tomorrow()).apply(); "tomorrow"
        }
    }
}
